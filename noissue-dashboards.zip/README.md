# noissue dashboards

One Vercel site for the service metrics, concessions and B2B delivery KPI dashboards.

| Page | Data |
|---|---|
| `/` | Links to each dashboard |
| `/service-metrics` | **Live** from *Service Metrics_Summary Table* (Raw Data and Overall tabs), refreshed within 5 minutes of a Sheet edit |
| `/concessions` | Snapshot (data embedded in the page, up to Sep 2026) |
| `/delivery-kpi` | Snapshot (data embedded in the page, up to Oct 2026) |

## How the live data works

The browser never talks to Google directly. `/api/sheets` is a small Vercel function that signs in to Google with a service account, reads only the ranges listed in `api/_sources.js`, and returns the cell values. Vercel caches each answer for 5 minutes, so Google is called at most a few times an hour however many people open the page.

`middleware.js` puts a password in front of every page and the API.

## One-time setup

### 1. Create the Google service account (about 10 minutes)

You may need someone with Google Cloud access at noissue for this.

1. Go to console.cloud.google.com and create a project (or reuse one), e.g. `noissue-dashboards`.
2. **APIs & Services → Library**: enable **Google Sheets API**.
3. **IAM & Admin → Service Accounts → Create service account**. Name it `dashboards-reader`. Skip the role step.
4. Open the new account → **Keys → Add key → Create new key → JSON**. A `.json` file downloads. Keep it private.

### 2. Give the service account read access to the Sheet

The service account's email looks like `dashboards-reader@noissue-dashboards.iam.gserviceaccount.com`.

Share **Service Metrics_Summary Table** with that email as **Viewer**. The file is in a shared drive, so this needs someone who can manage sharing there (a shared-drive manager, or the Sheet's owner). Alternatively, add the service account to the shared drive as a Viewer.

### 3. Deploy to Vercel

1. Push this folder to a GitHub repo (private) and import it in Vercel, or run `npx vercel` inside the folder.
2. In **Vercel → Project → Settings → Environment Variables**, add:

| Name | Value |
|---|---|
| `GOOGLE_SA_EMAIL` | `client_email` from the JSON key |
| `GOOGLE_SA_KEY` | `private_key` from the JSON key, pasted exactly, including `-----BEGIN PRIVATE KEY-----` |
| `DASH_PASSWORD` | The password people type to open the site |
| `DASH_USER` | Optional. The username, default `noissue` |

3. Redeploy so the variables take effect.

If your Vercel plan has **Vercel Authentication** (Settings → Deployment Protection) and you'd rather use noissue logins, turn that on and set `ALLOW_PUBLIC=true` to switch off the password prompt. Without either, the site shows a "locked" message instead of going public.

## When something breaks

The service metrics page shows the exact problem in red. The common ones:

- **"The service account can't open…"**: the Sheet isn't shared with the service account email, or it was moved to a drive the account can't see.
- **"GOOGLE_SA_EMAIL and GOOGLE_SA_KEY are not set"**: add the variables in Vercel, then redeploy.
- **"The Raw Data tab has no rows…"**: the wide table on Raw Data must still start at column G with a `Month` and `Channel` header. If the tab layout changes, update the range in `api/_sources.js`.

The page reads columns by their header names (e.g. `Fulfilled`, `Overall Concessions YTD`), so moving columns around is fine as long as the headers stay the same. Month labels can be `Jan-26`, `SEPT-2026` or `1/1/2026`. Percentages can be `0.973` or `97.3%`.

## Adding another live Sheet

1. Share the Sheet with the service account.
2. Add an entry to `api/_sources.js` with a key, the spreadsheet ID and the range.
3. Fetch it from the page with `/api/sheets?sources=your_key`.

## Files

```
index.html                     landing page
service-metrics/index.html     service metrics page
service-metrics/app.js         charts and tables
shared/service-metrics-data.js turns Sheet cells into clean numbers, plus the data checks
shared/nav.js                  top bar shared by every page
concessions/index.html         existing concessions dashboard (snapshot)
delivery-kpi/index.html        existing B2B delivery KPI dashboard (snapshot)
api/sheets.js                  reads Google Sheets with the service account
api/_sources.js                the only Sheet ranges the site may read
middleware.js                  password protection
```
