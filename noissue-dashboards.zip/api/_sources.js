// Every Google Sheet range the site is allowed to read.
// The browser asks for a source by its key, never by spreadsheet ID,
// so nobody can use /api/sheets to read other files the service account can see.
export const SOURCES = {
  service_raw: {
    title: 'Service Metrics_Summary Table: Raw Data',
    spreadsheetId: '1RDowp1LZa6lQ6nkwFC7BfpZsxdWFu_mT8F99v-1seAg',
    range: "'Raw Data'!G1:AF400",
  },
  service_overall: {
    title: 'Service Metrics_Summary Table: Overall',
    spreadsheetId: '1RDowp1LZa6lQ6nkwFC7BfpZsxdWFu_mT8F99v-1seAg',
    range: 'Overall!A1:E600',
  },
};
