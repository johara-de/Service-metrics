import { GoogleAuth } from 'google-auth-library';
import { SOURCES } from './_sources.js';

let authClient;
async function getToken() {
  const email = process.env.GOOGLE_SA_EMAIL;
  const key = process.env.GOOGLE_SA_KEY;
  if (!email || !key) {
    throw Object.assign(new Error('GOOGLE_SA_EMAIL and GOOGLE_SA_KEY are not set in Vercel → Settings → Environment Variables.'), { status: 500 });
  }
  if (!authClient) {
    const auth = new GoogleAuth({
      credentials: { client_email: email, private_key: key.replace(/\\n/g, '\n') },
      scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly'],
    });
    authClient = await auth.getClient();
  }
  const { token } = await authClient.getAccessToken();
  return token;
}

export default async function handler(req, res) {
  try {
    const wanted = String(req.query.sources || '').split(',').map((s) => s.trim()).filter(Boolean);
    const unknown = wanted.filter((k) => !SOURCES[k]);
    if (!wanted.length || unknown.length) {
      return res.status(400).json({ error: `Unknown or missing source: ${unknown.join(', ') || '(none)'}. Allowed: ${Object.keys(SOURCES).join(', ')}` });
    }

    const token = await getToken();

    // One batchGet per spreadsheet.
    const bySheet = {};
    for (const k of wanted) (bySheet[SOURCES[k].spreadsheetId] ||= []).push(k);

    const out = {};
    await Promise.all(Object.entries(bySheet).map(async ([id, keys]) => {
      const qs = keys.map((k) => 'ranges=' + encodeURIComponent(SOURCES[k].range)).join('&');
      const r = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${id}/values:batchGet?${qs}&valueRenderOption=FORMATTED_VALUE`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!r.ok) {
        const title = SOURCES[keys[0]].title.split(':')[0];
        const msg = r.status === 403 || r.status === 404
          ? `The service account can't open "${title}". Share it (Viewer) with ${process.env.GOOGLE_SA_EMAIL}.`
          : `Google Sheets returned ${r.status} for "${title}".`;
        throw Object.assign(new Error(msg), { status: 502 });
      }
      const body = await r.json();
      keys.forEach((k, i) => {
        out[k] = { title: SOURCES[k].title, values: body.valueRanges[i].values || [] };
      });
    }));

    // Cached at Vercel's edge for 5 minutes, served stale for up to 10 more while it refreshes.
    res.setHeader('Cache-Control', 's-maxage=300, stale-while-revalidate=600');
    return res.status(200).json({ fetchedAt: new Date().toISOString(), sources: out });
  } catch (e) {
    console.error(e);
    return res.status(e.status || 500).json({ error: e.message || 'Could not read Google Sheets.' });
  }
}
