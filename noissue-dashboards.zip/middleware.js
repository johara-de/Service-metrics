import { next } from '@vercel/functions';

// Password-protects every page and the /api/sheets endpoint.
// Set DASH_PASSWORD (and optionally DASH_USER, default "noissue") in Vercel.
// If you protect the site with Vercel Authentication instead, set ALLOW_PUBLIC=true.
export const config = { matcher: '/((?!_vercel|favicon).*)' };

export default function middleware(request) {
  if (process.env.ALLOW_PUBLIC === 'true') return next();

  const pass = process.env.DASH_PASSWORD;
  if (!pass) {
    return new Response('This site is locked until DASH_PASSWORD is set in Vercel → Settings → Environment Variables.', { status: 503 });
  }
  const user = process.env.DASH_USER || 'noissue';
  const header = request.headers.get('authorization') || '';
  if (header.startsWith('Basic ')) {
    const [u, ...rest] = atob(header.slice(6)).split(':');
    if (u === user && rest.join(':') === pass) return next();
  }
  return new Response('Sign in to view noissue dashboards.', {
    status: 401,
    headers: { 'WWW-Authenticate': 'Basic realm="noissue dashboards", charset="UTF-8"' },
  });
}
