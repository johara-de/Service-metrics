(function () {
  var S = window.SMData;
  var $ = function (id) { return document.getElementById(id); };
  var state = { raw: [], overall: [], month: null, channel: 'noissue', fetchedAt: null };
  var tip = $('tip');

  var C = { navy: '#17375E', blue: '#2F5597', sky: '#8EA9DB', mist: '#D6E0F2', good: '#1E6B4F', bad: '#A3341F', muted: '#5c6878' };
  var monthDate = function (k) { return new Date(Date.UTC(+k.slice(0, 4), +k.slice(5) - 1, 1)); };
  var mShort = d3.utcFormat('%b %y'), mLong = d3.utcFormat('%B %Y');
  var metric = function (k) { return S.METRICS.filter(function (m) { return m.key === k; })[0]; };
  var chanLabel = function (k) { return S.CHANNELS.filter(function (c) { return c.key === k; })[0].label; };

  // Service rates read as 97.3%, concession rates need two decimals (1.65%).
  function fmt(v, m) {
    if (v == null) return '–';
    return d3.format(m.group === 'service' ? '.1%' : '.2%')(v);
  }
  function delta(ty, ly, m) {
    if (ty == null || ly == null) return { text: 'no comparison', cls: 'flat' };
    var d = (ty - ly) * 100;
    var digits = m.group === 'service' ? 1 : 2;
    if (Math.abs(d) < Math.pow(10, -digits) / 2) return { text: 'no change', cls: 'flat' };
    var better = m.higherIsBetter ? d > 0 : d < 0;
    return { text: (d > 0 ? '+' : '−') + Math.abs(d).toFixed(digits) + ' pts', cls: better ? 'good' : 'bad' };
  }
  function showTip(ev, html) {
    tip.innerHTML = html; tip.style.opacity = 1;
    var x = Math.min(ev.clientX + 12, window.innerWidth - tip.offsetWidth - 8);
    tip.style.left = x + 'px'; tip.style.top = (ev.clientY + 14) + 'px';
  }
  function hideTip() { tip.style.opacity = 0; }

  // ---------- load ----------
  fetch('/api/sheets?sources=service_raw,service_overall', { credentials: 'same-origin' })
    .then(function (r) { return r.json().then(function (b) { if (!r.ok) throw new Error(b.error || 'Request failed (' + r.status + ')'); return b; }); })
    .then(function (body) {
      state.raw = S.parseRaw(body.sources.service_raw.values);
      state.overall = S.parseOverall(body.sources.service_overall.values);
      state.fetchedAt = new Date(body.fetchedAt);
      var months = S.months(state.raw);
      if (!months.length) throw new Error('The Raw Data tab has no rows with a Month and Channel. Check that the table still starts at column G.');
      state.month = months[months.length - 1];
      var hash = new URLSearchParams(location.hash.slice(1));
      if (months.indexOf(hash.get('month')) >= 0) state.month = hash.get('month');
      if (S.CHANNELS.some(function (c) { return c.key === hash.get('channel'); })) state.channel = hash.get('channel');
      setup(months);
      render();
    })
    .catch(function (e) {
      $('status').className = 'status error';
      $('status').textContent = 'Could not load service metrics. ' + e.message;
      $('source').textContent = 'Source: Service Metrics_Summary Table';
    });

  function setup(months) {
    $('source').textContent = 'Live from Service Metrics_Summary Table, read ' + d3.timeFormat('%-d %b %Y, %-I:%M %p')(state.fetchedAt) + '. Updates within 5 minutes of a Sheet edit.';
    var sel = d3.select('#month');
    sel.selectAll('option').data(months.slice().reverse()).join('option')
      .attr('value', function (d) { return d; }).text(function (d) { return mLong(monthDate(d)); });
    sel.property('value', state.month).on('change', function () { state.month = this.value; render(); });
    d3.select('#channel').selectAll('button').data(S.CHANNELS).join('button')
      .attr('type', 'button').text(function (d) { return d.label; })
      .on('click', function (ev, d) { state.channel = d.key; render(); });
    $('controls').hidden = false; $('status').hidden = true; $('content').hidden = false;
    var t; window.addEventListener('resize', function () { clearTimeout(t); t = setTimeout(render, 150); });
  }

  function render() {
    d3.selectAll('#channel button').attr('aria-pressed', function (d) { return d.key === state.channel; });
    history.replaceState(null, '', '#month=' + state.month + '&channel=' + state.channel);
    renderScore();
    trend('fulfilled', '#trend-fulfilled');
    trend('delivered', '#trend-delivered');
    concessions();
    compare();
    checks();
  }

  // ---------- scorecard ----------
  function renderScore() {
    var rec = S.record(state.raw, state.month, state.channel);
    var host = d3.select('#score').html('');
    if (!rec) { host.append('p').attr('class', 'status').text('No ' + chanLabel(state.channel) + ' row for ' + mLong(monthDate(state.month)) + ' in the Raw Data tab yet.'); return; }

    [['service', 'Service levels for ' + chanLabel(state.channel) + ', ' + mLong(monthDate(state.month))], ['concessions', 'Concession rates (lower is better)']].forEach(function (g) {
      var ms = S.METRICS.filter(function (m) { return m.group === g[0]; });
      var vals = [];
      ms.forEach(function (m) { var v = rec.metrics[m.key]; vals.push(v.ty, v.ly); });
      vals = vals.filter(function (v) { return v != null; });
      var lo = g[0] === 'service' ? Math.max(0, Math.floor((d3.min(vals) || 0.5) * 20 - 1) / 20) : 0;
      var hi = g[0] === 'service' ? 1 : Math.max(0.02, Math.ceil((d3.max(vals) || 0.02) * 100 + 0.5) / 100);

      var grp = host.append('div').attr('class', 'score-group');
      var gh = grp.append('div').attr('class', 'gh');
      gh.append('span').text(g[1]);
      var lg = gh.append('span').attr('class', 'legend');
      lg.append('span').html('<i style="background:' + C.navy + '"></i>This year');
      lg.append('span').html('<i style="background:#fff;border:2px solid ' + C.sky + ';width:8px;height:8px"></i>Same month last year');

      ms.forEach(function (m) {
        var v = rec.metrics[m.key], dl = delta(v.ty, v.ly, m), dy = delta(v.ytd, v.lytd, m);
        var row = grp.append('div').attr('class', 'score-row');
        row.append('div').attr('class', 'm-label').text(m.label);
        row.append('div').attr('class', 'm-ty').text(fmt(v.ty, m));
        dumbbell(row.append('div').attr('class', 'dumb'), v, m, lo, hi);
        row.append('div').attr('class', 'm-delta ' + dl.cls).html(dl.text + '<small>vs ' + fmt(v.ly, m) + ' last year</small>');
        row.append('div').attr('class', 'm-ytd').html('YTD ' + fmt(v.ytd, m) + '<small class="' + dy.cls + '">' + (dy.cls === 'flat' ? dy.text : dy.text + ' vs last YTD') + '</small>');
      });
    });
  }

  function dumbbell(el, v, m, lo, hi) {
    var w = el.node().clientWidth || 240, h = 34;
    var x = d3.scaleLinear().domain([lo, hi]).range([8, w - 8]).clamp(true);
    var svg = el.append('svg').attr('viewBox', '0 0 ' + w + ' ' + h).attr('role', 'img')
      .attr('aria-label', m.label + ': ' + fmt(v.ty, m) + ' this year, ' + fmt(v.ly, m) + ' last year');
    svg.append('line').attr('x1', x(lo)).attr('x2', x(hi)).attr('y1', h / 2).attr('y2', h / 2).attr('stroke', '#E3E8F0').attr('stroke-width', 2);
    if (v.ty == null) return;
    if (v.ly != null) {
      var better = m.higherIsBetter ? v.ty >= v.ly : v.ty <= v.ly;
      svg.append('line').attr('x1', x(v.ly)).attr('x2', x(v.ty)).attr('y1', h / 2).attr('y2', h / 2)
        .attr('stroke', better ? C.good : C.bad).attr('stroke-width', 4).attr('stroke-linecap', 'round').attr('opacity', 0.55);
      svg.append('circle').attr('cx', x(v.ly)).attr('cy', h / 2).attr('r', 6).attr('fill', '#fff').attr('stroke', C.sky).attr('stroke-width', 2.5);
    }
    svg.append('circle').attr('cx', x(v.ty)).attr('cy', h / 2).attr('r', 7).attr('fill', C.navy);
    svg.append('text').attr('x', x(lo)).attr('y', h).attr('fill', '#9AA5B4').attr('font-size', 10).text(d3.format('.0%')(lo));
    svg.append('text').attr('x', x(hi)).attr('y', h).attr('text-anchor', 'end').attr('fill', '#9AA5B4').attr('font-size', 10).text(d3.format(m.group === 'service' ? '.0%' : '.0%')(hi));
  }

  // ---------- trend lines ----------
  function trend(key, sel) {
    var m = metric(key), data = S.series(state.raw, state.overall, state.channel, key);
    var el = d3.select(sel).html('');
    if (!data.length) { el.append('p').attr('class', 'note').text('No ' + chanLabel(state.channel) + ' rows in the Overall tab.'); return; }
    var w = el.node().clientWidth || 520, h = 240, mg = { t: 12, r: 12, b: 28, l: 44 };
    var pts = data.map(function (d) { return { date: monthDate(d.month), month: d.month, ty: d.ty, ly: d.ly }; });
    var all = pts.reduce(function (a, d) { if (d.ty != null) a.push(d.ty); if (d.ly != null) a.push(d.ly); return a; }, []);
    var x = d3.scaleUtc().domain(d3.extent(pts, function (d) { return d.date; })).range([mg.l, w - mg.r]);
    var y = d3.scaleLinear().domain([Math.max(0, Math.floor(d3.min(all) * 20) / 20 - 0.05), 1]).nice().range([h - mg.b, mg.t]);
    var svg = el.append('svg').attr('viewBox', '0 0 ' + w + ' ' + h).attr('role', 'img').attr('aria-label', m.label + ' by month for ' + chanLabel(state.channel));
    svg.append('g').attr('class', 'grid').attr('transform', 'translate(' + mg.l + ',0)').call(d3.axisLeft(y).ticks(5).tickSize(-(w - mg.l - mg.r)).tickFormat(''));
    svg.append('g').attr('class', 'axis').attr('transform', 'translate(0,' + (h - mg.b) + ')').call(d3.axisBottom(x).ticks(Math.min(pts.length, w < 420 ? 4 : 8)).tickFormat(mShort));
    svg.append('g').attr('class', 'axis').attr('transform', 'translate(' + mg.l + ',0)').call(d3.axisLeft(y).ticks(5).tickFormat(d3.format('.0%'))).call(function (g) { g.select('.domain').remove(); });
    var line = function (f) { return d3.line().defined(function (d) { return d[f] != null; }).x(function (d) { return x(d.date); }).y(function (d) { return y(d[f]); }); };
    svg.append('path').datum(pts).attr('fill', 'none').attr('stroke', C.sky).attr('stroke-width', 2).attr('stroke-dasharray', '5 4').attr('d', line('ly'));
    svg.append('path').datum(pts).attr('fill', 'none').attr('stroke', C.navy).attr('stroke-width', 2.5).attr('d', line('ty'));
    var sel_ = state.month;
    svg.selectAll('circle.p').data(pts.filter(function (d) { return d.ty != null; })).join('circle').attr('class', 'p')
      .attr('cx', function (d) { return x(d.date); }).attr('cy', function (d) { return y(d.ty); })
      .attr('r', function (d) { return d.month === sel_ ? 5.5 : 3; })
      .attr('fill', function (d) { return d.month === sel_ ? C.navy : '#fff'; }).attr('stroke', C.navy).attr('stroke-width', 2)
      .on('mousemove', function (ev, d) { showTip(ev, '<b>' + mLong(d.date) + '</b><br>This year ' + fmt(d.ty, m) + '<br>Last year ' + fmt(d.ly, m)); })
      .on('mouseleave', hideTip);
  }

  // ---------- concession rates ----------
  function concessions() {
    var el = d3.select('#conc-chart').html('');
    var rows = state.raw.filter(function (r) { return r.channel === state.channel; }).sort(function (a, b) { return a.month < b.month ? -1 : 1; });
    if (!rows.length) return;
    var keys = ['overall', 'supplier', 'quality', 'shipper'];
    var colors = { overall: C.navy, supplier: C.blue, quality: '#6F8FCB', shipper: '#A9BDE3' };
    var w = el.node().clientWidth || 900, h = 260, mg = { t: 12, r: w < 600 ? 12 : 150, b: 28, l: 48 };
    var x = d3.scalePoint().domain(rows.map(function (r) { return r.month; })).range([mg.l, w - mg.r]).padding(0.3);
    var max = d3.max(rows, function (r) { return d3.max(keys, function (k) { return r.metrics[k].ty; }); }) || 0.02;
    var y = d3.scaleLinear().domain([0, max * 1.1]).nice().range([h - mg.b, mg.t]);
    var svg = el.append('svg').attr('viewBox', '0 0 ' + w + ' ' + h).attr('role', 'img').attr('aria-label', 'Concession rates by month for ' + chanLabel(state.channel));
    svg.append('g').attr('class', 'grid').attr('transform', 'translate(' + mg.l + ',0)').call(d3.axisLeft(y).ticks(5).tickSize(-(w - mg.l - mg.r)).tickFormat(''));
    svg.append('g').attr('class', 'axis').attr('transform', 'translate(0,' + (h - mg.b) + ')').call(d3.axisBottom(x).tickFormat(function (k) { return mShort(monthDate(k)); }));
    svg.append('g').attr('class', 'axis').attr('transform', 'translate(' + mg.l + ',0)').call(d3.axisLeft(y).ticks(5).tickFormat(d3.format('.1%'))).call(function (g) { g.select('.domain').remove(); });
    keys.forEach(function (k) {
      var m = metric(k);
      var line = d3.line().defined(function (r) { return r.metrics[k].ty != null; }).x(function (r) { return x(r.month); }).y(function (r) { return y(r.metrics[k].ty); });
      svg.append('path').datum(rows).attr('fill', 'none').attr('stroke', colors[k]).attr('stroke-width', k === 'overall' ? 3 : 2).attr('d', line);
      svg.selectAll('circle.' + k).data(rows.filter(function (r) { return r.metrics[k].ty != null; })).join('circle').attr('class', k)
        .attr('cx', function (r) { return x(r.month); }).attr('cy', function (r) { return y(r.metrics[k].ty); })
        .attr('r', function (r) { return r.month === state.month ? 5 : 3; }).attr('fill', colors[k])
        .on('mousemove', function (ev, r) { showTip(ev, '<b>' + m.label + '</b>, ' + mLong(monthDate(r.month)) + '<br>' + fmt(r.metrics[k].ty, m) + ' (last year ' + fmt(r.metrics[k].ly, m) + ')'); })
        .on('mouseleave', hideTip);
      if (w >= 600) {
        var last = rows.filter(function (r) { return r.metrics[k].ty != null; }).pop();
        if (last) svg.append('text').attr('x', x(last.month) + 10).attr('y', y(last.metrics[k].ty)).attr('dy', '0.35em')
          .attr('fill', colors[k] === '#A9BDE3' ? '#6F8FCB' : colors[k]).attr('font-size', 12).attr('font-weight', k === 'overall' ? 600 : 500).text(m.label);
      }
    });
    // Spread labels that collide.
    var labels = svg.selectAll('text').filter(function () { return !this.closest('.axis'); }).nodes()
      .sort(function (a, b) { return +a.getAttribute('y') - +b.getAttribute('y'); });
    for (var i = 1; i < labels.length; i++) {
      var prev = +labels[i - 1].getAttribute('y'), cur = +labels[i].getAttribute('y');
      if (cur - prev < 14) labels[i].setAttribute('y', prev + 14);
    }
  }

  // ---------- all channels table ----------
  function compare() {
    $('compare-title').textContent = 'All channels, ' + mLong(monthDate(state.month));
    var t = d3.select('#compare').html('');
    var head = t.append('thead').append('tr');
    head.append('th').text('Metric');
    S.CHANNELS.forEach(function (c) { head.append('th').text(c.label); });
    var body = t.append('tbody');
    S.METRICS.forEach(function (m) {
      var tr = body.append('tr');
      tr.append('td').text(m.label);
      S.CHANNELS.forEach(function (c) {
        var rec = S.record(state.raw, state.month, c.key), v = rec && rec.metrics[m.key];
        var td = tr.append('td');
        if (!v || v.ty == null) { td.text('–'); return; }
        var d = delta(v.ty, v.ly, m);
        td.html(fmt(v.ty, m) + '<small class="' + d.cls + '">' + d.text + '</small>');
        if (c.key === state.channel) td.style('background', '#F4F7FC');
      });
    });
  }

  // ---------- data checks ----------
  function checks() {
    var list = S.checks(state.raw, state.overall);
    $('checks-section').hidden = !list.length;
    d3.select('#checks').selectAll('li').data(list).join('li')
      .html(function (c) { return c.text + ' <span>(' + c.where + ')</span>'; });
  }
})();
