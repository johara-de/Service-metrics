// Shared top bar for every dashboard. Load it as the last script in <body>: src="/shared/nav.js".
(function () {
  var LINKS = [
    { href: '/', label: 'Home' },
    { href: '/service-metrics', label: 'Service metrics' },
    { href: '/concessions', label: 'Concessions' },
    { href: '/delivery-kpi', label: 'B2B delivery KPI' },
  ];
  var here = location.pathname.replace(/\/(index(\.html)?)?$/, '') || '/';
  var css = [
    '.site-bar{display:flex;align-items:center;gap:28px;padding:0 24px;height:52px;background:#17375E;color:#fff;',
    'font:500 14px/1 "IBM Plex Sans",system-ui,-apple-system,"Segoe UI",sans-serif;position:relative;z-index:50}',
    '.site-bar a{color:#C9D6EE;text-decoration:none;padding:17px 0 15px;border-bottom:2px solid transparent}',
    '.site-bar a:hover{color:#fff}',
    '.site-bar a[aria-current=page]{color:#fff;border-bottom-color:#8EA9DB}',
    '.site-bar a:focus-visible{outline:2px solid #fff;outline-offset:4px}',
    '.site-bar .site-brand{font-weight:600;color:#fff;margin-right:8px;letter-spacing:-.01em}',
    '.site-bar nav{display:flex;gap:24px;overflow-x:auto;scrollbar-width:none}',
    '@media (max-width:640px){.site-bar{gap:16px;padding:0 16px}.site-bar nav{gap:18px}.site-bar .site-brand{display:none}}',
    '@media print{.site-bar{display:none}}',
  ].join('');
  var style = document.createElement('style');
  style.textContent = css;
  document.head.appendChild(style);

  var bar = document.createElement('header');
  bar.className = 'site-bar';
  var brand = document.createElement('a');
  brand.href = '/'; brand.className = 'site-brand'; brand.textContent = 'noissue dashboards';
  bar.appendChild(brand);
  var nav = document.createElement('nav');
  nav.setAttribute('aria-label', 'Dashboards');
  LINKS.slice(1).forEach(function (l) {
    var a = document.createElement('a');
    a.href = l.href; a.textContent = l.label;
    if (here === l.href) a.setAttribute('aria-current', 'page');
    nav.appendChild(a);
  });
  bar.appendChild(nav);
  document.body.insertBefore(bar, document.body.firstChild);
})();
