// Turns the Service Metrics_Summary Table tabs into clean records.
// Works in the browser (window.SMData) and in Node (module.exports) so it can be tested.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.SMData = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  var METRICS = [
    { key: 'fulfilled', label: 'Fulfilled on time', sheet: 'Fulfilled', higherIsBetter: true, group: 'service' },
    { key: 'delivered', label: 'Delivered on time', sheet: 'Delivered', higherIsBetter: true, group: 'service' },
    { key: 'overall', label: 'Overall concessions', sheet: 'Overall Concessions', higherIsBetter: false, group: 'concessions' },
    { key: 'supplier', label: 'Supplier concessions', sheet: 'Supplier Concessions', higherIsBetter: false, group: 'concessions' },
    { key: 'quality', label: 'Quality related', sheet: 'Quality Related', higherIsBetter: false, group: 'concessions' },
    { key: 'shipper', label: 'Shipper concessions', sheet: 'Shipper Concessions', higherIsBetter: false, group: 'concessions' },
  ];
  var CHANNELS = [
    { key: 'noissue', label: 'noissue' },
    { key: 'b2b', label: 'B2B' },
    { key: 'self-service', label: 'Self Service' },
  ];
  var MON = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12 };

  function clean(s) { return String(s == null ? '' : s).trim(); }
  function norm(s) { return clean(s).toLowerCase().replace(/\s+/g, ' '); }

  // "0.823", "87.27%", "1,234" → number; blank → null
  function num(v) {
    var s = clean(v);
    if (!s || s === '-' || /^#/.test(s)) return null;
    var pct = /%$/.test(s);
    var n = parseFloat(s.replace(/[%,$\s]/g, ''));
    if (!isFinite(n)) return null;
    return pct ? n / 100 : n;
  }

  // "Jan-26", "SEPT-2026", "September 2026", "1/1/2026" → "2026-01"
  function monthKey(v) {
    var s = clean(v);
    var m = s.match(/^([A-Za-z]+)[\s\-_]+(\d{2,4})$/);
    if (m) {
      var mo = MON[m[1].toLowerCase().slice(0, 4)] || MON[m[1].toLowerCase().slice(0, 3)];
      var y = +m[2]; if (y < 100) y += 2000;
      if (mo) return y + '-' + String(mo).padStart(2, '0');
    }
    m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (m) return m[3] + '-' + String(+m[1]).padStart(2, '0');
    m = s.match(/^(\d{4})-(\d{2})/);
    if (m) return m[1] + '-' + m[2];
    return null;
  }

  function channelKey(v) {
    var s = norm(v);
    if (s === 'noissue') return 'noissue';
    if (s === 'b2b') return 'b2b';
    if (s === 'self service' || s === 'self-service' || s === 'selfservice') return 'self-service';
    return null;
  }

  function metricBySheet(name) {
    var s = norm(name);
    for (var i = 0; i < METRICS.length; i++) if (norm(METRICS[i].sheet) === s) return METRICS[i];
    return null;
  }

  function prevYear(key) { return (+key.slice(0, 4) - 1) + key.slice(4); }

  // Raw Data!G:AF — wide table, one row per month × channel. Stops at the first blank row
  // (below it the tab has a second, long-format block that Looker uses).
  function parseRaw(values) {
    if (!values || !values.length) return [];
    var head = values[0].map(norm);
    var col = function (name) { return head.indexOf(norm(name)); };
    var iMonth = col('Month'), iChan = col('Channel');
    var cols = {};
    METRICS.forEach(function (m) {
      cols[m.key] = { ty: col(m.sheet), ly: col(m.sheet + ' VS LY'), ytd: col(m.sheet + ' YTD'), lytd: col(m.sheet + ' LYTD') };
    });
    var out = [];
    for (var r = 1; r < values.length; r++) {
      var row = values[r] || [];
      if (!row.length || !clean(row[iMonth])) break;
      var month = monthKey(row[iMonth]), channel = channelKey(row[iChan]);
      if (!month || !channel) continue;
      var rec = { month: month, channel: channel, rowNumber: r + 1, metrics: {} };
      METRICS.forEach(function (m) {
        var c = cols[m.key], g = function (i) { return i < 0 ? null : num(row[i]); };
        rec.metrics[m.key] = { ty: g(c.ty), ly: g(c.ly), ytd: g(c.ytd), lytd: g(c.lytd) };
      });
      out.push(rec);
    }
    return out;
  }

  // Overall!A:E — long table: Month + Year, Metric, Channel, TY, LY
  function parseOverall(values) {
    if (!values || !values.length) return [];
    var head = values[0].map(norm);
    var iM = head.indexOf('month + year'), iMet = head.indexOf('metric'), iC = head.indexOf('channel'),
      iTY = head.indexOf('ty'), iLY = head.indexOf('ly');
    var out = [];
    for (var r = 1; r < values.length; r++) {
      var row = values[r] || [];
      var month = monthKey(row[iM]), metric = metricBySheet(row[iMet]), channel = channelKey(row[iC]);
      if (!month || !metric || !channel) continue;
      out.push({ month: month, metric: metric.key, channel: channel, ty: num(row[iTY]), ly: iLY < 0 ? null : num(row[iLY]), rowNumber: r + 1 });
    }
    return out;
  }

  // Monthly series for one channel and metric: Overall tab for history, Raw Data fills gaps.
  // LY falls back to the same month last year when the LY cell is blank.
  function series(raw, overall, channel, metric) {
    var byMonth = {};
    overall.forEach(function (o) {
      if (o.channel === channel && o.metric === metric && o.ty != null) byMonth[o.month] = { month: o.month, ty: o.ty, ly: o.ly };
    });
    raw.forEach(function (r) {
      if (r.channel !== channel) return;
      var v = r.metrics[metric];
      if (!v || v.ty == null) return;
      var cur = byMonth[r.month];
      if (!cur) byMonth[r.month] = { month: r.month, ty: v.ty, ly: v.ly };
      else if (cur.ly == null) cur.ly = v.ly;
    });
    var months = Object.keys(byMonth).sort();
    return months.map(function (k) {
      var d = byMonth[k];
      if (d.ly == null && byMonth[prevYear(k)]) d.ly = byMonth[prevYear(k)].ty;
      return d;
    });
  }

  function months(raw) {
    var s = {};
    raw.forEach(function (r) { s[r.month] = 1; });
    return Object.keys(s).sort();
  }

  function record(raw, month, channel) {
    for (var i = 0; i < raw.length; i++) if (raw[i].month === month && raw[i].channel === channel) return raw[i];
    return null;
  }

  // Things worth fixing in the Sheet. Each check explains itself in plain words.
  function checks(raw, overall) {
    var out = [];
    var label = function (k) { return CHANNELS.filter(function (c) { return c.key === k; })[0].label; };
    var mlabel = function (k) { return METRICS.filter(function (m) { return m.key === k; })[0].sheet; };
    raw.forEach(function (r) {
      if (r.month.slice(5) !== '01') return;
      METRICS.forEach(function (m) {
        var v = r.metrics[m.key];
        if (v.ty == null || v.ytd == null) return;
        if (Math.abs(v.ty - v.ytd) > 0.002) {
          out.push({ where: 'Raw Data row ' + r.rowNumber, text: label(r.channel) + ' ' + mlabel(m.key) + ': January YTD is ' + pctText(v.ytd) + ' but January TY is ' + pctText(v.ty) + '. In January they should match.' });
        }
      });
    });
    raw.forEach(function (r) {
      ['fulfilled', 'delivered'].forEach(function (k) {
        var has = overall.some(function (o) { return o.month === r.month && o.channel === r.channel && o.metric === k && o.ty != null; });
        if (!has && r.metrics[k].ty != null) {
          out.push({ where: 'Overall tab', text: label(r.channel) + ' ' + mlabel(k) + ' for ' + monthText(r.month) + ' is in Raw Data (' + pctText(r.metrics[k].ty) + ') but missing from the Overall tab, so Looker charts skip it.' });
        }
      });
    });
    return out;
  }

  function monthText(k) { var n = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']; return n[+k.slice(5) - 1] + ' ' + k.slice(0, 4); }
  function pctText(v) { return (v * 100).toFixed(Math.abs(v) < 0.1 ? 2 : 1) + '%'; }

  return {
    METRICS: METRICS, CHANNELS: CHANNELS,
    num: num, monthKey: monthKey, channelKey: channelKey,
    parseRaw: parseRaw, parseOverall: parseOverall,
    series: series, months: months, monthText: monthText, record: record, checks: checks,
  };
});
